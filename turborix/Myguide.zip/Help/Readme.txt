
Do not delete MyGuide directory structure.
The application mainshell.exe will detect presence of \My Flash Disk\MyGuide\MyGuide\MyGuide.exe
In MyGuide.scp the navigation program can be specified.
MyGuide.exe is actually a copy op Mioautorun.exe using script MyGuide.scp.