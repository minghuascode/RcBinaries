Exceet 6ch Tx and Flysky CT6A/B driver install
1) Plug USB cable into PC and determine if you have a Prolithic or SI Labs USB to serial cable. 
2) Windows should tell you which one it is looking for, Once it does that, exit the Driver installation.
3) Go into the folder of the appropriate driver and run the install program.



Running T6Config
1) Install T6config by clicking on T6Config.exe 
2) Click through the prompts
3) Plug in your cable to TX and turn on Tx.
4) Plug USB cable into PC (you should have already completed the driver install)
5) Select your com port (a new com port would have been added during the driver install)
6) Make sure it's communicating by moving sticks around and viewing the green/blackbars moving
7) CLICK GETUSER BEFORE you make any changes. Failing to do so may wipe out your stored information in the Tx.

If all goes wrong, you can restore the included "Working settings" file to hopefully get some life back in the unit.

T6config does NOT like com ports higher than com 9. 
If your USB driver selects com9, then find the USB device in hardware manager 
and go to the properties section and change the com port.

Save your settings to a default file so you can come back to it.
Do not keep saving the same file name, you want to be able to revert back to a previous file if you mess something up. Name them incrementally Blueray1, Blueray2, etc.
My default file is particular to MY helicopter, Your Endpoints and Subtrims are likely to be different.

Visit http://www.mycoolheli.com/t6config
for more information